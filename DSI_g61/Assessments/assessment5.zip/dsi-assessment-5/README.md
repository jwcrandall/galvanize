# Assessment 5

### Profit Curves, Web Scraping, NLP, Naive Bayes and Clustering

* Open Book
* ***Time: 60 minutes***
