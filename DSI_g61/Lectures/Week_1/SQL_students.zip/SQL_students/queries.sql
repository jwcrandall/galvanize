/*
Implementing queries from
Introduction to SQL for Data Scientists
*/

-- Look at the tables and data shown in Section 1.2

/* 
Question 0: Uncomment the query below to run it.
It should give the results of the first query
in Section 2 of the paper.
*/

/*
SELECT
    s.id AS id,
    s.name AS name
FROM
    student AS s
WHERE
    s.id = 1;
*/



/*
Question 1: Write a query that will return the
students whose first name starts with an H.
*/








-- Back to lecture

/*
Question 2: Write a query that returns what terms degrees were 
awarded.
*/








/*
Question 3: Write a query that counts the number of times a term
g.p.a. was above 3.
*/







-- Back to lecture

/*
Question 4: Uncomment and run this query that uses a join to 
duplicate the second set of results in Section 2 of the paper.
*/

/*
SELECT
    s.id AS id,
    s.name AS name,
    t.gpa AS gpa
FROM
    student AS s
JOIN
    term_gpa AS t
ON
    s.id = t.id
WHERE
    s.id = 1
    AND
    t.term = 2012;
*/


/*
Question 5: Write a query that will find and display Edith Warton's 
and Henry James's gpas for 2011 and 2012.
*/












/* Question 6: Write a query that will find Edith Warton's and Henry 
James's highest gpas rounded to two decimal places.  Order them by 
whoever has the highest gpa.
*/













-- Back to lecture


/* 
Question 7.  In one table list all the students, the term they were 
enrolled, their gpa for that term, and the degree they received 
(if they received one).  Consider using a left join here.
*/













/* 
Query 8: Find the students who have graduated (they have their
degree). Consider using GROUP BY.
*/










/*
Query 9:  Find the students who haven't graduated and their average 
gpa, rounded to two decimal places. You may want to use a subquery.
*/














-- Back to lecture

